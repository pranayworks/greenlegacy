Place your logo.png, hero.jpg, and tree images in this folder before deploying. They are referenced by the frontend CSS/HTML.
