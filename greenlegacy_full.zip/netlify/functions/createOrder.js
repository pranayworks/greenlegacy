const Razorpay = require('razorpay');

exports.handler = async function(event, context) {
  // Expect POST with JSON {name, email, occasion, treeType, count, amount}
  if (event.httpMethod !== 'POST') {
    return { statusCode: 400, body: 'Only POST allowed' };
  }
  const data = JSON.parse(event.body || '{}');

  const key_id = process.env.RAZORPAY_KEY_ID;
  const key_secret = process.env.RAZORPAY_KEY_SECRET;
  if(!key_id || !key_secret){
    return { statusCode: 500, body: JSON.stringify({error:'Razorpay keys not configured'})};
  }

  const instance = new Razorpay({ key_id, key_secret });

  const amount = parseInt(data.amount) || 500;
  const options = {
    amount: amount * 100,
    currency: 'INR',
    receipt: 'receipt_' + Math.floor(Math.random()*1000000),
    payment_capture: 1
  };

  try {
    const order = await instance.orders.create(options);
    return {
      statusCode: 200,
      body: JSON.stringify({ order })
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
