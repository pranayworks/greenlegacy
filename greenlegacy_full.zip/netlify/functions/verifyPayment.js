const crypto = require('crypto');
const admin = require('firebase-admin');

// Initialize Firebase admin lazily to avoid re-init in serverless environment
function initFirebase() {
  if (admin.apps && admin.apps.length) return admin.app();
  const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT;
  if(!serviceAccountJson) throw new Error('FIREBASE_SERVICE_ACCOUNT env var missing');
  const serviceAccount = JSON.parse(serviceAccountJson);
  return admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    projectId: process.env.FIREBASE_PROJECT_ID || serviceAccount.project_id
  });
}

exports.handler = async function(event, context) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 400, body: 'Only POST allowed' };
  }
  const data = JSON.parse(event.body || '{}');
  /*
    Expect data:
    {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      name, email, occasion, treeType, count, amount
    }
  */
  const key_secret = process.env.RAZORPAY_KEY_SECRET;
  if(!key_secret){
    return { statusCode: 500, body: JSON.stringify({error:'Razorpay key secret not configured'})};
  }

  // Verify signature
  const generated_signature = crypto.createHmac('sha256', key_secret)
    .update(data.razorpay_order_id + '|' + data.razorpay_payment_id)
    .digest('hex');

  if (generated_signature !== data.razorpay_signature) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid signature' }) };
  }

  // On successful verification, write record to Firestore
  try {
    initFirebase();
    const db = admin.firestore();
    const treeId = 'GLF-' + Math.floor(Math.random()*900000 + 100000);
    const record = {
      treeId,
      name: data.name || 'Anonymous',
      email: data.email || '',
      occasion: data.occasion || '',
      treeType: data.treeType || '',
      count: data.count || 1,
      amount: data.amount || 0,
      razorpay_order_id: data.razorpay_order_id,
      razorpay_payment_id: data.razorpay_payment_id,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      status: 0 // sapling
    };
    await db.collection('trees').doc(treeId).set(record);
    return { statusCode: 200, body: JSON.stringify({ success:true, treeId }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
