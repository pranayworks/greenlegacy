// Frontend logic: create order -> open Razorpay -> verify -> show certificate
async function getAmountForTree(treeType, count){
  const priceMap = { Neem:500, Mango:700, Peepal:600, Gulmohar:500, Tulsi:200 };
  return (priceMap[treeType] || 500) * (count || 1);
}

async function refreshAmount(){
  const treeType = document.getElementById('treeType').value;
  const count = parseInt(document.getElementById('count').value || '1');
  const amt = await getAmountForTree(treeType, count);
  document.getElementById('amount').value = amt;
  document.getElementById('summary').innerText = `You are planting ${count} x ${treeType}. Total: ₹${amt}`;
}

document.getElementById('treeType').addEventListener('change', refreshAmount);
document.getElementById('count').addEventListener('input', refreshAmount);
window.addEventListener('load', refreshAmount);

document.getElementById('startPayment').addEventListener('click', async function(){
  const name = document.getElementById('donorName').value || 'Anonymous';
  const email = document.getElementById('donorEmail').value || '';
  const occasion = document.getElementById('occasion').value || '';
  const treeType = document.getElementById('treeType').value;
  const count = parseInt(document.getElementById('count').value || '1');
  const amount = parseInt(document.getElementById('amount').value || '500');

  // create order via Netlify function
  const res = await fetch('/.netlify/functions/createOrder', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, occasion, treeType, count, amount })
  });
  const data = await res.json();
  if(!data.order){
    alert('Could not create order: ' + (data.error || JSON.stringify(data)));
    return;
  }
  const order = data.order;

  const options = {
    key: window.RAZORPAY_KEY || '', // optional: if configured client-side
    amount: order.amount,
    currency: order.currency,
    name: 'GreenLegacy',
    description: `${count} x ${treeType}`,
    order_id: order.id,
    handler: async function (response){
      // verify payment on server
      const verifyRes = await fetch('/.netlify/functions/verifyPayment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          razorpay_order_id: response.razorpay_order_id,
          razorpay_payment_id: response.razorpay_payment_id,
          razorpay_signature: response.razorpay_signature,
          name, email, occasion, treeType, count, amount
        })
      });
      const verifyData = await verifyRes.json();
      if(verifyData.success){
        const treeId = verifyData.treeId;
        document.getElementById('donationMsg').innerText = `Thanks ${name}! Donation successful. Tree ID: ${treeId}`;
        document.getElementById('certificateBox').classList.remove('hidden');
        document.getElementById('certText').innerText = `${name} planted ${count} ${treeType} tree(s). Tree ID: ${treeId}`;
        // store locally as demo
        const rec = { treeId, name, treeType, count, date: new Date().toISOString(), status:0 };
        const arr = JSON.parse(localStorage.getItem('glf_demo')||'[]');
        arr.push(rec);
        localStorage.setItem('glf_demo', JSON.stringify(arr));
      } else {
        alert('Verification failed: ' + (verifyData.error || JSON.stringify(verifyData)));
      }
    },
    theme: { color: '#2e7d32' }
  };
  const rzp = new Razorpay(options);
  rzp.open();
});

// Track function - read from Firestore via REST (public) or localStorage demo
document.getElementById('trackBtn').addEventListener('click', async function(){
  const q = document.getElementById('trackId').value.trim();
  if(!q){ document.getElementById('trackResult').innerText = 'Enter Tree ID'; return; }
  // first check local demo
  const arr = JSON.parse(localStorage.getItem('glf_demo')||'[]');
  const found = arr.find(r=> r.treeId === q);
  if(found){
    document.getElementById('trackResult').innerHTML = `<strong>Tree ID:</strong> ${found.treeId}<br><strong>Type:</strong> ${found.treeType}<br><strong>Date:</strong> ${new Date(found.date).toLocaleDateString()}<br><strong>Status:</strong> Sapling`;
    return;
  }
  // If not in local demo, attempt Firestore REST (public collection)
  const projectId = window.FIREBASE_PROJECT_ID || '';
  if(!projectId){
    document.getElementById('trackResult').innerText = 'Tree not found in demo, and Firestore not configured.';
    return;
  }
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/trees/${q}`;
    const resp = await fetch(url);
    if(!resp.ok){ throw new Error('Not found'); }
    const doc = await resp.json();
    const fields = doc.fields || {};
    const name = fields.name?.stringValue || '';
    const type = fields.treeType?.stringValue || '';
    const count = fields.count?.integerValue || '1';
    const created = fields.createdAt?.timestampValue || '';
    const status = ['Sapling','Growing','Young','Mature'][parseInt(fields.status?.integerValue||'0')];
    document.getElementById('trackResult').innerHTML = `<strong>Tree ID:</strong> ${q}<br><strong>Donor:</strong> ${name}<br><strong>Type:</strong> ${type}<br><strong>Count:</strong> ${count}<br><strong>Status:</strong> ${status}`;
  } catch(e){
    document.getElementById('trackResult').innerText = 'Tree not found.';
  }
});

// Certificate download
document.getElementById('downloadCert').addEventListener('click', function(){
  const text = document.getElementById('certText').innerText || 'GreenLegacy Certificate';
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  doc.setFontSize(18);
  doc.text('GreenLegacy Foundation', 20, 30);
  doc.setFontSize(12);
  doc.text(text, 20, 50);
  doc.save('greenlegacy_certificate.pdf');
});
